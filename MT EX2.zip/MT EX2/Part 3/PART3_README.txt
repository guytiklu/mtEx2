Train:
To run the train model please run 'run_train2' batch script.
First, edit the batch file for the paths of: 'train.src' 'train.trg' 'dev.src' 'dev.trg', or use the ones provided.
You can also change the example # from 0 to any value from 0 to len(dev_set) to get heatmaps for other example.
The batch script will install the libraries specified in 'requirements.txt' and then run the program.
