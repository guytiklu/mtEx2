import pickle
import sys
import random
import numpy as np
import torch
import torch.nn as nn
from torchtext.data import Field, BucketIterator
from models2 import Encoder, Decoder, Seq2Seq
import helper2 as h
import matplotlib.pyplot as plt
import matplotlib.ticker as ticker

TRAIN_FILE_SRC = sys.argv[1]
TRAIN_FILE_TRG = sys.argv[2]
DEV_FILE_SRC = sys.argv[3]
DEV_FILE_TRG = sys.argv[4]
DUMP_HEATMAP = sys.argv[5]
HEATMAP_EXAMPLE = int(sys.argv[6])

# make the results deterministic
SEED = 4321
random.seed(SEED)
np.random.seed(SEED)
torch.manual_seed(SEED)
torch.cuda.manual_seed(SEED)
torch.backends.cudnn.deterministic = True


def export_models(enc, dec, model):
    torch.save(enc, 'enc.pt')
    torch.save(dec, 'dec.pt')
    torch.save(model, 'seq2seq.pt')


def train(model, iterator, optimizer, criterion, clip):
    model.train()

    epoch_loss = 0

    for i, batch in enumerate(iterator):
        src = batch.src
        trg = batch.trg

        optimizer.zero_grad()

        output, _ = model(src, trg[:, :-1])

        # output = [batch size, trg len - 1, output dim]
        # trg = [batch size, trg len]

        output_dim = output.shape[-1]

        output = output.contiguous().view(-1, output_dim)
        trg = trg[:, 1:].contiguous().view(-1)

        # output = [batch size * trg len - 1, output dim]
        # trg = [batch size * trg len - 1]

        loss = criterion(output, trg)

        loss.backward()

        torch.nn.utils.clip_grad_norm_(model.parameters(), clip)

        optimizer.step()

        epoch_loss += loss.item()

    return epoch_loss / len(iterator)


def evaluate(model, device, iterator, criterion, SRC, TRG, epoch):
    model.eval()

    refs = []
    hyps = []
    epoch_loss = 0

    with torch.no_grad():
        for i, batch in enumerate(iterator):
            src = batch.src
            trg = batch.trg

            output, _ = model(src, trg[:, :-1])

            output_dim = output.shape[-1]
            output = output.contiguous().view(-1, output_dim)
            trg = trg[:, 1:].contiguous().view(-1)

            src_example = ' '.join(batch.dataset.examples[i].src)
            translation, attention = translate_seq(src_example, SRC, TRG, model, device)
            to_word = ''.join(translation[:-1])
            hyps.append(to_word)
            correct_translation = ''.join(batch.dataset.examples[i].trg)
            refs.append(correct_translation)

            if i == HEATMAP_EXAMPLE and DUMP_HEATMAP == 'yes':
                # export heatmap to file
                s = batch.dataset.examples[i].src
                display_attention(s, translation, attention, epoch, 16, 4, 4)

            loss = criterion(output, trg)

            epoch_loss += loss.item()

        # print(refs)
        # print(hyps)
        # calc loss and bleu:
        loss = round(epoch_loss / len(iterator), 2)
        bleu_score = h.calculate_bleu(hyps, refs)

    return loss, bleu_score


def translate_seq(seq, src_field, trg_field, model, device, max_len=50):
    model.eval()

    if isinstance(seq, str):
        tokens = h.tokenize_src(seq)

    tokens = [src_field.init_token] + tokens + [src_field.eos_token]

    src_indexes = [src_field.vocab.stoi[token] for token in tokens]

    src_tensor = torch.LongTensor(src_indexes).unsqueeze(0).to(device)

    src_mask = model.make_src_mask(src_tensor)

    with torch.no_grad():
        enc_src = model.encoder(src_tensor, src_mask)

    trg_indexes = [trg_field.vocab.stoi[trg_field.init_token]]

    for i in range(max_len):

        trg_tensor = torch.LongTensor(trg_indexes).unsqueeze(0).to(device)

        trg_mask = model.make_trg_mask(trg_tensor)

        with torch.no_grad():
            output, attention = model.decoder(trg_tensor, enc_src, trg_mask, src_mask)

        pred_token = output.argmax(2)[:, -1].item()

        trg_indexes.append(pred_token)

        if pred_token == trg_field.vocab.stoi[trg_field.eos_token]:
            break

    trg_tokens = [trg_field.vocab.itos[i] for i in trg_indexes]

    return trg_tokens[1:], attention


def display_attention(sentence, translation, attention, filename, n_heads=8, n_rows=4, n_cols=2):
    assert n_rows * n_cols == n_heads

    fig = plt.figure(figsize=(15, 25))

    for i in range(n_heads):
        ax = fig.add_subplot(n_rows, n_cols, i + 1)

        _attention = attention.squeeze(0)[i].cpu().detach().numpy()

        cax = ax.matshow(_attention, cmap='bone')

        ax.tick_params(labelsize=12)
        ax.set_xticklabels([''] + ['<start>'] + [t.lower() for t in sentence] + ['<end>'],
                           rotation=45)
        ax.set_yticklabels([''] + translation)

        ax.xaxis.set_major_locator(ticker.MultipleLocator(1))
        ax.yaxis.set_major_locator(ticker.MultipleLocator(1))

    plt.savefig(str(filename) + '.png')
    #plt.show()
    plt.close()


if __name__ == '__main__':
    # get train data:
    train_src_text, train_trg_text = h.get_text_from_files(TRAIN_FILE_SRC, TRAIN_FILE_TRG)
    # get dev data:
    dev_src_text, dev_trg_text = h.get_text_from_files(DEV_FILE_SRC, DEV_FILE_TRG)

    # def fields for torchtext:
    SRC = Field(tokenize=h.tokenize_src,
                init_token='<start>',
                eos_token='<end>',
                lower=False,
                batch_first=True)

    TRG = Field(tokenize=h.tokenize_trg,
                init_token='<start>',
                eos_token='<end>',
                lower=False,
                batch_first=True)

    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    print('Using ' + device.type)

    # create data sets:
    train_data = h.create_tokenized_data_set_from_src_trg(train_src_text, train_trg_text, SRC, TRG)
    dev_data = h.create_tokenized_data_set_from_src_trg(dev_src_text, dev_trg_text, SRC, TRG)

    # build vocab (turn tokenized words to int values)
    SRC.build_vocab(train_data)
    TRG.build_vocab(train_data)

    # save SRC and TRG
    trg_save_file = open('trg.obj', 'wb')
    pickle.dump(TRG, trg_save_file)
    src_save_file = open('src.obj', 'wb')
    pickle.dump(SRC, src_save_file)

    # create iterators for sets:
    train_iterator, dev_iterator = BucketIterator.splits(
        (train_data, dev_data),
        batch_size=1,
        device=device,
        sort=False)

    # create model:
    INPUT_DIM = len(SRC.vocab)
    OUTPUT_DIM = len(TRG.vocab)
    HID_DIM = 256
    ENC_LAYERS = 1
    DEC_LAYERS = 1
    ENC_HEADS = 16
    DEC_HEADS = 16
    ENC_PF_DIM = 512
    DEC_PF_DIM = 512
    ENC_DROPOUT = 0.1
    DEC_DROPOUT = 0.1
    EPOCHS = 10
    CLIP = 1

    enc = Encoder(INPUT_DIM,
                  HID_DIM,
                  ENC_LAYERS,
                  ENC_HEADS,
                  ENC_PF_DIM,
                  ENC_DROPOUT,
                  device)

    dec = Decoder(OUTPUT_DIM,
                  HID_DIM,
                  DEC_LAYERS,
                  DEC_HEADS,
                  DEC_PF_DIM,
                  DEC_DROPOUT,
                  device)

    SRC_PAD_IDX = SRC.vocab.stoi[SRC.pad_token]
    TRG_PAD_IDX = TRG.vocab.stoi[TRG.pad_token]

    model = Seq2Seq(enc, dec, SRC_PAD_IDX, TRG_PAD_IDX, device).to(device)
    model.apply(h.init_weights)

    LEARNING_RATE = 0.0001
    optimizer = torch.optim.Adam(model.parameters(), lr=LEARNING_RATE)

    criterion = nn.CrossEntropyLoss(ignore_index=TRG_PAD_IDX)

    best_bleu = 0

    # train the model:
    for epoch in range(EPOCHS):
        print('Epoch #' + str(epoch + 1))
        train_loss = train(model, train_iterator, optimizer, criterion, CLIP)
        dev_loss, bleu_score = evaluate(model, device, dev_iterator, criterion, SRC, TRG, epoch+1)
        bleu_score_val = round(bleu_score.score, 2)
        print('Loss: ' + str(dev_loss))
        print('BLEU Score: ' + str(bleu_score_val))
        print()
        if bleu_score_val > best_bleu:
            best_bleu = bleu_score_val
            export_models(enc, dec, model)
        # translation, attention = translate_seq('40 116 104 101 110 ', SRC, TRG, model, device)
        # print(translation)
        # translation, attention = translate_seq('97', SRC, TRG, model, device)
        # print(translation)
        # translation, attention = translate_seq('112 111 114 116 114 97 105 116 115 41', SRC, TRG, model, device)
        # print(translation)


