import pickle
import sys
import random
import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
from torchtext.data import Field, BucketIterator
from models import Encoder, Decoder, Seq2Seq
import helper as h

TRAIN_FILE_SRC = sys.argv[1]
TRAIN_FILE_TRG = sys.argv[2]
DEV_FILE_SRC = sys.argv[3]
DEV_FILE_TRG = sys.argv[4]

# make the results deterministic
SEED = 1234
random.seed(SEED)
np.random.seed(SEED)
torch.manual_seed(SEED)
torch.cuda.manual_seed(SEED)
torch.backends.cudnn.deterministic = True


def export_models(enc, dec, model):
    torch.save(enc, 'enc.pt')
    torch.save(dec, 'dec.pt')
    torch.save(model, 'seq2seq.pt')


def train(model, iterator, optimizer, criterion, clip):
    model.train()

    epoch_loss = 0

    for i, batch in enumerate(iterator):
        src = batch.src
        trg = batch.trg

        optimizer.zero_grad()

        output = model(src, trg)

        # trg = [trg len, batch size]
        # output = [trg len, batch size, output dim]

        output_dim = output.shape[-1]

        output = output[1:].view(-1, output_dim)
        trg = trg[1:].view(-1)

        # trg = [(trg len - 1) * batch size]
        # output = [(trg len - 1) * batch size, output dim]

        loss = criterion(output, trg)

        loss.backward()

        torch.nn.utils.clip_grad_norm_(model.parameters(), clip)

        optimizer.step()

        epoch_loss += loss.item()

    return epoch_loss / len(iterator)


def evaluate(model, iterator, criterion, TRG):
    model.eval()

    refs = []
    hyps = []
    epoch_loss = 0

    with torch.no_grad():
        for i, batch in enumerate(iterator):
            src = batch.src
            trg = batch.trg

            output = model(src, trg, 0)  # turn off teacher forcing

            output_dim = output.shape[-1]
            output = output[1:].view(-1, output_dim)
            trg = trg[1:].view(-1)

            translation = h.prediction_to_text(output, TRG)
            hyps.append(translation)
            correct_translation = ''.join(batch.dataset.examples[i].trg)
            refs.append(correct_translation)

            loss = criterion(output, trg)

            epoch_loss += loss.item()

        # calc loss and bleu:
        loss = round(epoch_loss / len(iterator), 2)
        bleu_score = h.calculate_bleu(hyps, refs)

    return loss, bleu_score


if __name__ == '__main__':
    # get train data:
    train_src_text, train_trg_text = h.get_text_from_files(TRAIN_FILE_SRC, TRAIN_FILE_TRG)
    # get dev data:
    dev_src_text, dev_trg_text = h.get_text_from_files(DEV_FILE_SRC, DEV_FILE_TRG)

    # def fields for torchtext:
    SRC = Field(tokenize=h.tokenize_src,
                init_token='<start>',
                eos_token='<end>',
                lower=False)

    TRG = Field(tokenize=h.tokenize_trg,
                init_token='<start>',
                eos_token='<end>',
                lower=False)

    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    print('Using ' + device.type)

    # create data sets:
    train_data = h.create_tokenized_data_set_from_src_trg(train_src_text, train_trg_text, SRC, TRG)
    dev_data = h.create_tokenized_data_set_from_src_trg(dev_src_text, dev_trg_text, SRC, TRG)

    # build vocab (turn tokenized words to int values)
    SRC.build_vocab(train_data)
    TRG.build_vocab(train_data)

    # save SRC and TRG
    trg_save_file = open('trg.obj', 'wb')
    pickle.dump(TRG, trg_save_file)
    src_save_file = open('src.obj', 'wb')
    pickle.dump(SRC, src_save_file)

    # create iterators for sets:
    train_iterator, dev_iterator = BucketIterator.splits(
        (train_data, dev_data),
        batch_size=1,
        device=device,
        sort=False)

    # create model:
    INPUT_DIM = len(SRC.vocab)
    OUTPUT_DIM = len(TRG.vocab)
    ENC_EMB_DIM = 256
    DEC_EMB_DIM = 256
    HID_DIM = 512
    N_LAYERS = 2
    ENC_DROPOUT = 0.5
    DEC_DROPOUT = 0.5
    EPOCHS = 10
    CLIP = 1

    enc = Encoder(INPUT_DIM, ENC_EMB_DIM, HID_DIM, N_LAYERS, ENC_DROPOUT)
    dec = Decoder(OUTPUT_DIM, DEC_EMB_DIM, HID_DIM, N_LAYERS, DEC_DROPOUT)
    model = Seq2Seq(enc, dec, device).to(device)
    model.apply(h.init_weights)
    # define optimizer:
    optimizer = optim.Adam(model.parameters())
    # define loss, ignoring the 'pad' tokens:
    TRG_PAD_IDX = TRG.vocab.stoi[TRG.pad_token]
    criterion = nn.CrossEntropyLoss(ignore_index=TRG_PAD_IDX)

    best_bleu = 0

    # train the model:
    for epoch in range(EPOCHS):
        print('Epoch #' + str(epoch + 1))
        train_loss = train(model, train_iterator, optimizer, criterion, CLIP)
        dev_loss, bleu_score = evaluate(model, dev_iterator, criterion, TRG)
        bleu_score_val = round(bleu_score.score, 2)
        print('Loss: ' + str(dev_loss))
        print('BLEU Score: ' + str(bleu_score_val))
        print()
        if bleu_score_val > best_bleu:
            best_bleu = bleu_score_val
            export_models(enc, dec, model)
