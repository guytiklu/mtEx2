import pickle
import sys
import torch
import helper as h
import torch.nn as nn
from torchtext.data import BucketIterator

TEST_FILE_SRC = sys.argv[1]
TEST_FILE_TRG = sys.argv[2]


def evaluate(model, iterator, criterion, TRG):
    model.eval()

    refs = []
    hyps = []
    epoch_loss = 0

    with torch.no_grad():
        for i, batch in enumerate(iterator):
            src = batch.src
            trg = batch.trg

            output = model(src, trg, 0)  # turn off teacher forcing

            output_dim = output.shape[-1]
            output = output[1:].view(-1, output_dim)
            trg = trg[1:].view(-1)

            translation = h.prediction_to_text(output, TRG)
            hyps.append(translation)
            correct_translation = ''.join(batch.dataset.examples[i].trg)
            refs.append(correct_translation)
            print('Translation: ' + translation + '  |||  Correct translation: ' + correct_translation)

            loss = criterion(output, trg)

            epoch_loss += loss.item()

        # calc loss and bleu:
        loss = round(epoch_loss / len(iterator), 2)
        bleu_score = h.calculate_bleu(hyps, refs)

    return loss, bleu_score


if __name__ == '__main__':
    # load needed components
    trg_file = open('trg.obj', 'rb')
    TRG = pickle.load(trg_file)
    src_file = open('src.obj', 'rb')
    SRC = pickle.load(src_file)

    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    print('Using ' + device.type)

    test_src_text, test_trg_text = h.get_text_from_files(TEST_FILE_SRC, TEST_FILE_TRG)
    test_data = h.create_tokenized_data_set_from_src_trg(test_src_text, test_trg_text, SRC, TRG)
    test_iterator = BucketIterator(test_data, batch_size=1, device=device, sort=False, train=False, shuffle=False)

    TRG_PAD_IDX = TRG.vocab.stoi[TRG.pad_token]
    criterion = nn.CrossEntropyLoss(ignore_index=TRG_PAD_IDX)

    # import saved model:
    model = torch.load('seq2seq.pt')

    # predict + evaluate:
    print('Test set predictions:')
    test_loss, bleu_score = evaluate(model, test_iterator, criterion, TRG)
    bleu_score_val = round(bleu_score.score, 2)
    print('Loss: ' + str(test_loss))
    print('BLEU Score: ' + str(bleu_score_val))
