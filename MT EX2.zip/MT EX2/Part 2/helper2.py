import torch
from sacrebleu.metrics import BLEU
import torchtext.data
import torch.nn as nn


def init_weights(m):
    if hasattr(m, 'weight') and m.weight.dim() > 1:
        nn.init.xavier_uniform_(m.weight.data)


def get_text_from_files(src_file, trg_file):
    src_text = open(src_file, 'r').readlines()
    trg_text = open(trg_file, 'r').readlines()
    for i, sequence in enumerate(src_text):
        if sequence[-1] == '\n':
            src_text[i] = sequence[:-1]
    for i, sequence in enumerate(trg_text):
        if sequence[-1] == '\n':
            trg_text[i] = sequence[:-1]
    return src_text, trg_text


def tokenize_src(text):
    """
    Tokenizes SRC text from a string into a list of strings (tokens) and reverses it
    """
    return text.split()


def tokenize_trg(text):
    """
    Tokenizes TRG text from a string into a list of strings (tokens)
    """
    return text.split()


def create_tokenized_data_set_from_src_trg(src, trg, src_field, trg_field):
    # create examples:
    fields = {'src': [['src', src_field]], 'trg': [['trg', trg_field]]}
    examples = []
    for i in range(len(src)):
        example_dict = {'src': tokenize_src(src[i]), 'trg': tokenize_trg(trg[i])}
        train_example = torchtext.data.example.Example.fromdict(example_dict, fields)
        examples.append(train_example)
    fields = {'src': src_field, 'trg': trg_field}
    dataset = torchtext.data.dataset.Dataset(examples, fields)
    return dataset


def prediction_to_text(logits, tokenizer):
    """
    Turn logits from a neural network into text using the tokenizer
    :param logits: Logits from a neural network
    :param tokenizer: Keras Tokenizer fit on the labels
    :return: String that represents the text of the logits
    """
    vocab = tokenizer.vocab.stoi
    index_to_words = {id: word for word, id in vocab.items()}
    predictions = ''
    for line in logits:
        prediction = torch.argmax(line).item()
        char = index_to_words[prediction]
        if char not in ['<start>', '<end>']:
            predictions = predictions + char
    return predictions


def calculate_bleu(hyps, refs):
    bleu2 = BLEU(max_ngram_order=4)
    res = bleu2.corpus_score(hyps, [refs])
    return res