Train:
To run the train model please run 'run_train2' batch script.
First, edit the batch file for the paths of: 'train.src' 'train.trg' 'dev.src' 'dev.trg', or use the ones provided.
The batch script will install the libraries specified in 'requirements.txt' and then run the program.

Evaluation:
To run the evaulation model please run 'run_evaluation2' batch script.
First, edit the batch file for the paths of:'test.src' 'test.trg', or use the ones provided.
The batch script will install the libraries specified in 'requirements.txt' and then run the program.