import pickle
import sys
import torch
import helper2 as h
import torch.nn as nn
from torchtext.data import BucketIterator

TEST_FILE_SRC = sys.argv[1]
TEST_FILE_TRG = sys.argv[2]


def evaluate(model, device, iterator, criterion, SRC, TRG):
    model.eval()

    refs = []
    hyps = []
    epoch_loss = 0

    with torch.no_grad():
        for i, batch in enumerate(iterator):
            src = batch.src
            trg = batch.trg

            output, _ = model(src, trg[:, :-1])

            output_dim = output.shape[-1]
            output = output.contiguous().view(-1, output_dim)
            trg = trg[:, 1:].contiguous().view(-1)

            src_example = ' '.join(batch.dataset.examples[i].src)
            translation, attention = translate_seq(src_example, SRC, TRG, model, device)
            to_word = ' '.join(translation[:-1])
            hyps.append(to_word)
            correct_translation = ' '.join(batch.dataset.examples[i].trg)
            refs.append(correct_translation)
            print('Translation: ' + to_word + '  |||  Correct translation: ' + correct_translation)

            loss = criterion(output, trg)

            epoch_loss += loss.item()

        print(refs)
        print(hyps)
        # calc loss and bleu:
        loss = round(epoch_loss / len(iterator), 2)
        bleu_score = h.calculate_bleu(hyps, refs)

    return loss, bleu_score


def translate_seq(seq, src_field, trg_field, model, device, max_len=50):
    model.eval()

    if isinstance(seq, str):
        tokens = h.tokenize_src(seq)

    tokens = [src_field.init_token] + tokens + [src_field.eos_token]

    src_indexes = [src_field.vocab.stoi[token] for token in tokens]

    src_tensor = torch.LongTensor(src_indexes).unsqueeze(0).to(device)

    src_mask = model.make_src_mask(src_tensor)

    with torch.no_grad():
        enc_src = model.encoder(src_tensor, src_mask)

    trg_indexes = [trg_field.vocab.stoi[trg_field.init_token]]

    for i in range(max_len):

        trg_tensor = torch.LongTensor(trg_indexes).unsqueeze(0).to(device)

        trg_mask = model.make_trg_mask(trg_tensor)

        with torch.no_grad():
            output, attention = model.decoder(trg_tensor, enc_src, trg_mask, src_mask)

        pred_token = output.argmax(2)[:, -1].item()

        trg_indexes.append(pred_token)

        if pred_token == trg_field.vocab.stoi[trg_field.eos_token]:
            break

    trg_tokens = [trg_field.vocab.itos[i] for i in trg_indexes]

    return trg_tokens[1:], attention



if __name__ == '__main__':
    # load needed components
    trg_file = open('trg.obj', 'rb')
    TRG = pickle.load(trg_file)
    src_file = open('src.obj', 'rb')
    SRC = pickle.load(src_file)

    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    print('Using ' + device.type)

    test_src_text, test_trg_text = h.get_text_from_files(TEST_FILE_SRC, TEST_FILE_TRG)
    test_data = h.create_tokenized_data_set_from_src_trg(test_src_text, test_trg_text, SRC, TRG)
    test_iterator = BucketIterator(test_data, batch_size=1, device=device, sort=False, train=False, shuffle=False)

    TRG_PAD_IDX = TRG.vocab.stoi[TRG.pad_token]
    criterion = nn.CrossEntropyLoss(ignore_index=TRG_PAD_IDX)

    # import saved model:
    model = torch.load('seq2seq.pt')

    # predict + evaluate:
    print('Test set predictions:')
    test_loss, bleu_score = evaluate(model, device, test_iterator, criterion, SRC, TRG)
    bleu_score_val = round(bleu_score.score, 2)
    print('Loss: ' + str(test_loss))
    print('BLEU Score: ' + str(bleu_score_val))
